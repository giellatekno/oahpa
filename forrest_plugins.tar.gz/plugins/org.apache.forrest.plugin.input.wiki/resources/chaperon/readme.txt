These are the resources used by Chaperon.

This is an exact copy of cocoon-2.1/src/blocks/chaperon/samples. 
Please try to keep it in synch.

sitemap.xmap is not used directly but kept here as a reference.

When there will be real blocks, all this will not be needed and 
we will simply use the resources in the chaperon block.
